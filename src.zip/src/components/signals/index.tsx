// =============================================================================
// FILE: src/components/signals/index.tsx
// =============================================================================
// Enhanced User Signal Display Components
// UPDATED: Aligned with backend SignalResponse - shows all available data
// =============================================================================

import React, { useState } from "react";
import { 
  UserSignal, 
  UserSignalDetail,
  SignalStatus,
  formatPrice,
  formatPercent,
  getDecisionColor,
  getDecisionBgColor,
  getConsensusColor,
  getLeverageColor,
} from "../../types/signals.types";
import { Card, Badge, Spinner, Button, EmptyState } from "../ui/index";

// =============================================================================
// Signal Card (Enhanced User View)
// =============================================================================

interface SignalCardProps {
  signal: UserSignal;
  onClick?: () => void;
  showDetails?: boolean;
}

export const SignalCard: React.FC<SignalCardProps> = ({ signal, onClick, showDetails = true }) => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getDecisionIcon = (decision: string) => {
    switch (decision?.toLowerCase()) {
      case "long":
        return "↑";
      case "short":
        return "↓";
      default:
        return "→";
    }
  };

  const isActive = signal.status === SignalStatus.ACTIVE || signal.status === "active";
  const decision = (signal.decision as string)?.toLowerCase() || "hold";

  return (
    <Card 
      className="p-5 cursor-pointer transition-all duration-200 hover:scale-[1.02]" 
      hover 
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <span className="text-lg font-bold text-white">{signal.symbol}</span>
          <span
            className={`
              inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border font-bold text-sm
              ${getDecisionBgColor(decision)} ${getDecisionColor(decision)}
            `}
          >
            <span>{getDecisionIcon(decision)}</span>
            {decision.toUpperCase()}
          </span>
        </div>
        <Badge
          variant={isActive ? "success" : "warning"}
          dot
          pulse={isActive}
          size="sm"
        >
          {isActive ? "Active" : (signal.status as string)?.charAt(0).toUpperCase() + (signal.status as string)?.slice(1)}
        </Badge>
      </div>

      {/* Consensus & Confidence */}
      {showDetails && (
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Consensus</span>
            <span className={`text-sm font-semibold ${getConsensusColor(signal.consensus_strength)}`}>
              {signal.consensus_strength?.toFixed(0) || 0}%
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Confidence</span>
            <span className="text-sm font-semibold text-slate-300">
              {((signal.avg_confidence || 0) * 100).toFixed(0)}%
            </span>
          </div>
          {signal.suggested_leverage && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Leverage</span>
              <span className={`text-sm font-semibold ${getLeverageColor(signal.suggested_leverage)}`}>
                {signal.suggested_leverage}x
              </span>
            </div>
          )}
        </div>
      )}

      {/* Price Info Grid */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="p-3 bg-slate-800/50 rounded-xl">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Entry</p>
          <p className="text-base font-semibold text-white font-mono">
            {formatPrice(signal.entry_price)}
          </p>
        </div>
        <div className="p-3 bg-slate-800/50 rounded-xl">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Stop Loss</p>
          <p className="text-base font-semibold text-rose-400 font-mono">
            {formatPrice(signal.stop_loss_price)}
          </p>
          {signal.stop_loss_percent && (
            <p className="text-xs text-rose-400/70">
              {formatPercent(-Math.abs(signal.stop_loss_percent))}
            </p>
          )}
        </div>
        <div className="p-3 bg-slate-800/50 rounded-xl">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Take Profit</p>
          <p className="text-base font-semibold text-emerald-400 font-mono">
            {formatPrice(signal.take_profit_price)}
          </p>
          {signal.take_profit_percent && (
            <p className="text-xs text-emerald-400/70">
              {formatPercent(signal.take_profit_percent)}
            </p>
          )}
        </div>
      </div>

      {/* Risk/Reward & Models */}
      {showDetails && (
        <div className="flex items-center justify-between text-sm mb-3">
          {signal.risk_reward_ratio && (
            <div className="flex items-center gap-2">
              <span className="text-slate-500">R:R</span>
              <span className={`font-medium ${signal.risk_reward_ratio >= 2 ? 'text-emerald-400' : signal.risk_reward_ratio >= 1.5 ? 'text-amber-400' : 'text-slate-400'}`}>
                1:{signal.risk_reward_ratio.toFixed(1)}
              </span>
            </div>
          )}
          {signal.active_providers && signal.active_providers > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Models</span>
              <span className="font-medium text-sky-400">{signal.active_providers}</span>
            </div>
          )}
        </div>
      )}

      {/* Model Decisions Pills */}
      {showDetails && signal.provider_decisions && Object.keys(signal.provider_decisions).length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {Object.entries(signal.provider_decisions).slice(0, 4).map(([model, modelDecision]) => (
            <span
              key={model}
              className={`
                text-xs px-2 py-0.5 rounded-full border
                ${getDecisionBgColor(modelDecision)} ${getDecisionColor(modelDecision)}
              `}
            >
              {model.split(' ')[0]}
            </span>
          ))}
          {Object.keys(signal.provider_decisions).length > 4 && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400">
              +{Object.keys(signal.provider_decisions).length - 4}
            </span>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between text-sm text-slate-500 pt-2 border-t border-slate-700/50">
        <span>{formatDate(signal.created_at)}</span>
        {signal.source && (
          <span className="text-xs px-2 py-0.5 bg-slate-800 rounded text-slate-400">
            {signal.source.replace(/_/g, ' ')}
          </span>
        )}
      </div>
    </Card>
  );
};

// =============================================================================
// Signal Detail Modal
// =============================================================================

interface SignalDetailModalProps {
  signal: UserSignalDetail | null;
  isOpen: boolean;
  onClose: () => void;
  isLoading?: boolean;
}

export const SignalDetailModal: React.FC<SignalDetailModalProps> = ({
  signal,
  isOpen,
  onClose,
  isLoading = false,
}) => {
  if (!isOpen) return null;

  const decision = (signal?.decision as string)?.toLowerCase() || "hold";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center gap-4">
            {signal && (
              <>
                <h2 className="text-xl font-bold text-white">{signal.symbol}</h2>
                <span
                  className={`
                    inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border font-bold
                    ${getDecisionBgColor(decision)} ${getDecisionColor(decision)}
                  `}
                >
                  {decision === 'long' ? '↑' : decision === 'short' ? '↓' : '→'}
                  {decision.toUpperCase()}
                </span>
              </>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Spinner size="lg" />
            </div>
          ) : signal ? (
            <div className="space-y-6">
              {/* Consensus & Confidence Row */}
              <div className="grid grid-cols-4 gap-4">
                <MetricCard
                  label="Consensus"
                  value={`${signal.consensus_strength?.toFixed(0) || 0}%`}
                  valueClass={getConsensusColor(signal.consensus_strength)}
                />
                <MetricCard
                  label="Confidence"
                  value={`${((signal.avg_confidence || 0) * 100).toFixed(0)}%`}
                />
                <MetricCard
                  label="Leverage"
                  value={signal.suggested_leverage ? `${signal.suggested_leverage}x` : '—'}
                  valueClass={getLeverageColor(signal.suggested_leverage)}
                />
                <MetricCard
                  label="R:R Ratio"
                  value={signal.risk_reward_ratio ? `1:${signal.risk_reward_ratio.toFixed(1)}` : '—'}
                  valueClass={signal.risk_reward_ratio && signal.risk_reward_ratio >= 2 ? 'text-emerald-400' : undefined}
                />
              </div>

              {/* Price Levels */}
              <div>
                <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider">
                  Price Levels
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <PriceCard label="Current" value={signal.current_price} color="slate" />
                  <PriceCard label="Entry" value={signal.entry_price} color="blue" />
                  <PriceCard label="Stop Loss" value={signal.stop_loss_price} color="rose" percent={signal.stop_loss_percent ? -Math.abs(signal.stop_loss_percent) : undefined} />
                  <PriceCard label="Take Profit" value={signal.take_profit_price} color="emerald" percent={signal.take_profit_percent ?? undefined} />
                </div>
              </div>

              {/* Model Decisions */}
              {signal.model_responses && Object.keys(signal.model_responses).length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider">
                    AI Model Decisions ({Object.keys(signal.model_responses).length} models)
                  </h3>
                  <div className="space-y-3">
                    {Object.entries(signal.model_responses).map(([modelName, modelData]) => (
                      <ModelDecisionCard key={modelName} name={modelName} data={modelData} />
                    ))}
                  </div>
                </div>
              )}

              {/* Legacy Provider Decisions */}
              {!signal.model_responses && signal.providers && Object.keys(signal.providers).length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider">
                    Provider Decisions
                  </h3>
                  <div className="space-y-3">
                    {Object.entries(signal.providers).map(([providerName, providerData]) => (
                      <ModelDecisionCard key={providerName} name={providerName} data={providerData} />
                    ))}
                  </div>
                </div>
              )}

              {/* Reasoning Summary */}
              {signal.reasoning_summary && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider">
                    Analysis Summary
                  </h3>
                  <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                    <p className="text-sm text-slate-300 whitespace-pre-wrap">
                      {signal.reasoning_summary}
                    </p>
                  </div>
                </div>
              )}

              {/* Metadata */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-4 border-t border-slate-700">
                {signal.decision_method && (
                  <MetaItem label="Decision Method" value={signal.decision_method.replace(/_/g, ' ')} />
                )}
                {signal.high_confidence_votes !== undefined && (
                  <MetaItem label="High Confidence Votes" value={signal.high_confidence_votes.toString()} />
                )}
                {signal.analysis_duration_ms && (
                  <MetaItem label="Analysis Time" value={`${(signal.analysis_duration_ms / 1000).toFixed(1)}s`} />
                )}
                {signal.timeframes_analyzed && signal.timeframes_analyzed.length > 0 && (
                  <MetaItem label="Timeframes" value={signal.timeframes_analyzed.join(', ')} />
                )}
                {signal.source && (
                  <MetaItem label="Source" value={signal.source.replace(/_/g, ' ')} />
                )}
                <MetaItem label="Created" value={new Date(signal.created_at).toLocaleString()} />
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">
              No signal data available
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// =============================================================================
// Helper Components
// =============================================================================

const MetricCard: React.FC<{ label: string; value: string; valueClass?: string }> = ({
  label,
  value,
  valueClass = 'text-white',
}) => (
  <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">{label}</p>
    <p className={`text-xl font-bold ${valueClass}`}>{value}</p>
  </div>
);

const PriceCard: React.FC<{
  label: string;
  value: number | null | undefined;
  color: 'slate' | 'blue' | 'rose' | 'emerald';
  percent?: number;
}> = ({ label, value, color, percent }) => {
  const colorClasses = {
    slate: 'text-slate-300',
    blue: 'text-sky-400',
    rose: 'text-rose-400',
    emerald: 'text-emerald-400',
  };

  return (
    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/50">
      <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">{label}</p>
      <p className={`text-lg font-semibold font-mono ${colorClasses[color]}`}>
        {formatPrice(value)}
      </p>
      {percent !== undefined && (
        <p className={`text-xs ${color === 'rose' ? 'text-rose-400/70' : 'text-emerald-400/70'}`}>
          {formatPercent(percent)}
        </p>
      )}
    </div>
  );
};

const ModelDecisionCard: React.FC<{ name: string; data: any }> = ({ name, data }) => {
  const decision = data?.decision?.toLowerCase() || 'hold';
  const confidence = data?.confidence;
  const reasoning = data?.reasoning;

  return (
    <div className="p-4 bg-slate-800/30 rounded-xl border border-slate-700/50">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <span className="font-medium text-white">{data?.display_name || name}</span>
          <span
            className={`
              text-xs px-2 py-0.5 rounded-full border font-medium
              ${getDecisionBgColor(decision)} ${getDecisionColor(decision)}
            `}
          >
            {decision.toUpperCase()}
          </span>
        </div>
        {confidence !== undefined && (
          <span className="text-sm text-slate-400">
            {(confidence * 100).toFixed(0)}% confident
          </span>
        )}
      </div>
      {reasoning && (
        <p className="text-sm text-slate-400 mt-2 line-clamp-3">{reasoning}</p>
      )}
      {(data?.entry_price || data?.stop_loss_price || data?.take_profit_price) && (
        <div className="flex gap-4 mt-3 text-xs text-slate-500">
          {data?.entry_price && <span>Entry: {formatPrice(data.entry_price)}</span>}
          {data?.stop_loss_price && <span>SL: {formatPrice(data.stop_loss_price)}</span>}
          {data?.take_profit_price && <span>TP: {formatPrice(data.take_profit_price)}</span>}
        </div>
      )}
    </div>
  );
};

const MetaItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div>
    <p className="text-xs text-slate-500 uppercase tracking-wider">{label}</p>
    <p className="text-sm text-slate-300 capitalize">{value}</p>
  </div>
);

// =============================================================================
// Signal List
// =============================================================================

interface SignalListProps {
  signals: UserSignal[];
  isLoading: boolean;
  error: string | null;
  onSignalClick?: (signal: UserSignal) => void;
  onRetry?: () => void;
}

export const SignalList: React.FC<SignalListProps> = ({
  signals,
  isLoading,
  error,
  onSignalClick,
  onRetry,
}) => {
  if (isLoading && signals.length === 0) {
    return (
      <div className="flex items-center justify-center py-16">
        <Spinner size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-8">
        <EmptyState
          icon={
            <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              />
            </svg>
          }
          title="Failed to Load Signals"
          description={error}
          action={
            onRetry && (
              <Button variant="secondary" onClick={onRetry}>
                Try Again
              </Button>
            )
          }
        />
      </Card>
    );
  }

  if (signals.length === 0) {
    return (
      <Card className="p-8">
        <EmptyState
          icon={
            <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1}
                d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
              />
            </svg>
          }
          title="No Signals Available"
          description="Check back later for new trading signals"
        />
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {signals.map((signal) => (
        <SignalCard
          key={signal.id}
          signal={signal}
          onClick={() => onSignalClick?.(signal)}
        />
      ))}
    </div>
  );
};

// =============================================================================
// Signal Filters
// =============================================================================

interface SignalFiltersProps {
  symbols: string[];
  selectedSymbol: string;
  selectedDecision: string;
  onSymbolChange: (symbol: string) => void;
  onDecisionChange: (decision: string) => void;
  onClear: () => void;
  onRefresh: () => void;
}

export const SignalFilters: React.FC<SignalFiltersProps> = ({
  symbols,
  selectedSymbol,
  selectedDecision,
  onSymbolChange,
  onDecisionChange,
  onClear,
  onRefresh,
}) => {
  const hasFilters = selectedSymbol || selectedDecision;

  return (
    <div className="flex flex-wrap items-center gap-3">
      {/* Symbol Filter */}
      <select
        value={selectedSymbol}
        onChange={(e) => onSymbolChange(e.target.value)}
        className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
      >
        <option value="">All Symbols</option>
        {symbols.map((symbol) => (
          <option key={symbol} value={symbol}>
            {symbol}
          </option>
        ))}
      </select>

      {/* Decision Filter */}
      <select
        value={selectedDecision}
        onChange={(e) => onDecisionChange(e.target.value)}
        className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
      >
        <option value="">All Decisions</option>
        <option value="long">Long</option>
        <option value="short">Short</option>
      </select>

      {/* Clear Filters */}
      {hasFilters && (
        <Button variant="ghost" size="sm" onClick={onClear}>
          Clear
        </Button>
      )}

      {/* Refresh */}
      <Button variant="secondary" size="sm" onClick={onRefresh}>
        <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
          />
        </svg>
        Refresh
      </Button>
    </div>
  );
};
